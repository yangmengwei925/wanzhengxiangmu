export default {
    '404':'没有文件',
    '200':'请求成功'
}