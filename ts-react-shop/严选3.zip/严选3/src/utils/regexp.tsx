export let mobileReg = /^1[3456789]\d{9}$/;

export let passwordReg = /^[a-zA-Z0-9]{6,12}/;