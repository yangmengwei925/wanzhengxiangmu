import axios from '../utils/request'

export let getHomeList = () => axios.get("/")