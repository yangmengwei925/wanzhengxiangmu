module.exports={
    devServer:{
        proxy:"http://169.254.180.113:7001"
    }
}
