<template>
    <div class="dialog">
        tankuang 
        111111111111111111111
    </div>
</template>
<script>
export default {
    props:{

    },
    components:{

    },
    data(){
        return {

        }
    },
    computed:{

    },
    methods:{

    },
    created(){

    },
    mounted(){

    }
}
</script>
<style scoped lang="scss">
.dialog{
    color:white;
}
</style>