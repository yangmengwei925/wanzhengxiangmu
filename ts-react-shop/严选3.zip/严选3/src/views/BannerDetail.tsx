import React from 'react';

function BannerDetail() {
  return (
    <div className="BannerDetail">
      图片详情 -- 动态路由
    </div>
  );
}

export default BannerDetail;